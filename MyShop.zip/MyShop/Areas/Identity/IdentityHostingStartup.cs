﻿using System;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MyShop.Areas.Identity.Data;
using MyShop.Data;

[assembly: HostingStartup(typeof(MyShop.Areas.Identity.IdentityHostingStartup))]
namespace MyShop.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                services.AddDbContext<ShopDbContext>(options =>
                    options.UseSqlServer(
                        context.Configuration.GetConnectionString("ShopDbContextConnection")));

                services.AddDefaultIdentity<ApplicationUser>(options => options.SignIn.RequireConfirmedAccount = false)
                    .AddEntityFrameworkStores<ShopDbContext>();
            });
        }
    }
}